package com.example.taskmanagement.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.taskmanagement.entity.Task;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api/tasks")
public class TaskController {

    private final Map<Long, Task> tasks = new HashMap<>();
    private long currentId = 1;

    // CREATE
    @PostMapping("/create")
    public Task createTask(@RequestBody Task task) {
        task.setId(currentId++);
        tasks.put(task.getId(), task);
        return task;
    }

    // READ all
    @GetMapping("/all")
    public List<Task> getAllTasks() {
        return new ArrayList<>(tasks.values());
    }

    // READ one
    @GetMapping("/get/{id}")
    public Task getTaskById(@PathVariable Long id) {
        return tasks.get(id);
    }

    // UPDATE
    @PutMapping("/update/{id}")
    public Task updateTask(@PathVariable Long id, @RequestBody Task task) {
        if (tasks.containsKey(id)) {
            task.setId(id);
            tasks.put(id, task);
            return task;
        }
        return null; // Could return 404
    }

    // DELETE
    @DeleteMapping("/delete/{id}")
    public String deleteTask(@PathVariable Long id) {
        if (tasks.containsKey(id)) {
            tasks.remove(id);
            return "Task with id " + id + " deleted successfully.";
        }
        return "Task not found.";
    }
}
